"""
starter/build_vectorstore.py — Meridian Freight & Logistics

============================ YOUR TASK ============================
Fill in the TODOs below based on the predictions you wrote in Part 1
of the worksheet. Don't just make it run — make your choices match
your reasoning about THIS client's specific needs.
======================================================================

Read documents/, redact PII, chunk, embed, and store in ChromaDB.
"""

import glob
import os
import sys
import json
import re
import shutil

sys.path.insert(
    0,
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "..",
        "toolkit"
    )
)

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma

# TODO 1:
# Import loaders for all document formats supplied by Meridian.
from loaders import load_pdf, load_html, load_csv, load_json

from chunking import chunk_text
from pii import redact_pii

load_dotenv()


EMBED_MODEL = "text-embedding-3-small"
COLLECTION_NAME = "meridian_documents"
PERSIST_DIR = "./chroma_store"


# TODO 2:
# The Leave Policy is organised into numbered sections.
# Heading-aware chunking keeps related policy rules together.
CHUNK_STRATEGY = "heading_aware"


# TODO 3:
# Each CSV row represents one complete pay-band record containing
# location, role band, pay range and effective quarter.
# Therefore, each row is kept as a single chunk with no further splitting.


def build():
    print("=" * 64)
    print("Meridian Freight & Logistics — Building the Knowledge Base")
    print(f"Chunking strategy in use: {CHUNK_STRATEGY}")
    print("=" * 64)

    filepaths = sorted(glob.glob("../documents/*"))

    all_documents = []
    total_pii_redactions = {}

    for filepath in filepaths:

        filename = os.path.basename(filepath)

        print(f"\nProcessing {filename} ...")

        document_version = ""

        # ------------------------------------------------------------
        # TODO 4: Select the correct loader based on file extension.
        # ------------------------------------------------------------

        ext = os.path.splitext(filepath)[1].lower()

        if ext == ".pdf":
            raw_units = load_pdf(filepath)

        elif ext in (".html", ".htm"):
            raw_units = load_html(filepath)

        elif ext == ".csv":
            raw_units = load_csv(
                filepath,
                id_column="location_code"
            )

        elif ext == ".json":
            raw_units = load_json(
                filepath,
                list_key="open_positions"
            )

        else:
            print(f"Skipping unsupported file: {filename}")
            continue


        # ------------------------------------------------------------
        # Extract document version for citation metadata.
        # ------------------------------------------------------------

        if ext == ".json":

            with open(filepath, "r", encoding="utf-8") as f:
                json_data = json.load(f)

            document_version = str(
                json_data.get("version", "")
            )

        elif ext in (".pdf", ".html", ".htm"):

            for unit in raw_units:

                version_match = re.search(
                    r"Version:\s*([0-9.]+)",
                    unit["text"],
                    re.IGNORECASE
                )

                if version_match:
                    document_version = version_match.group(1)
                    break


        # ------------------------------------------------------------
        # TODO 5:
        # Redact PII before chunking so sensitive information is not
        # carried into chunks that will later be embedded and stored.
        # ------------------------------------------------------------

        for unit in raw_units:

            redacted_text, redaction_counts = redact_pii(
                unit["text"]
            )

            for label, count in redaction_counts.items():

                total_pii_redactions[label] = (
                    total_pii_redactions.get(label, 0)
                    + count
                )


            # --------------------------------------------------------
            # TODO 6:
            # CSV rows are already complete structured records.
            # Do not split them further.
            # Other formats use the selected heading-aware strategy.
            # --------------------------------------------------------

            if ext == ".csv":

                chunks = [redacted_text]

            else:

                chunks = chunk_text(
                    redacted_text,
                    strategy=CHUNK_STRATEGY
                )


            # --------------------------------------------------------
            # TODO 7:
            # Preserve loader metadata and attach source, chunk index,
            # and document version where available.
            # --------------------------------------------------------

            for chunk_index, chunk in enumerate(chunks):

                metadata = unit["metadata"].copy()

                metadata["source"] = filename
                metadata["chunk_index"] = chunk_index

                if document_version:
                    metadata["version"] = document_version

                all_documents.append(
                    Document(
                        page_content=chunk,
                        metadata=metadata
                    )
                )


    print(
        f"\nTotal chunks to embed: "
        f"{len(all_documents)}"
    )

    if total_pii_redactions:

        print(
            f"PII redacted at ingest: "
            f"{total_pii_redactions}"
        )


    # ------------------------------------------------------------
    # TODO 8:
    # Embed the processed documents and persist them in ChromaDB.
    # ------------------------------------------------------------

    print(
        "\nEmbedding and storing in ChromaDB "
        "(this calls the OpenAI API)..."
    )

    embeddings = OpenAIEmbeddings(
        model=EMBED_MODEL
    )

    # Fresh start every run so rebuilding does not duplicate data.
    if os.path.exists(PERSIST_DIR):
        shutil.rmtree(PERSIST_DIR)

    Chroma.from_documents(
        documents=all_documents,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=PERSIST_DIR,
    )

    print(
        "Build complete. "
        "Next: fill in ../starter/app.py"
    )


if __name__ == "__main__":
    build()