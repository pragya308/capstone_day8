"""
starter/app.py — Meridian Freight & Logistics

============================ YOUR TASK ============================
This is the FastAPI backend. Every TODO below corresponds to a
prediction you made in Part 1 of the worksheet. Implement each one to
match your reasoning — if a TODO's implementation contradicts what you
predicted, that's worth noticing and discussing, not silently ignoring.
======================================================================

Run with: uvicorn app:app --reload --port 8000
(from inside the starter/ folder, AFTER build_vectorstore.py has run)
"""

import os
import sys

sys.path.insert(
    0,
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "..",
        "toolkit"
    )
)

from dotenv import load_dotenv
from fastapi import FastAPI
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from openai import OpenAI

from context import assemble_context
from pii import redact_pii
from confidence import (
    confidence_level,
    should_refuse,
    best_score_from_results,
)
from observability import Tracer
from hybrid_retrieval import HybridIndex

import audit_log


load_dotenv()


CHAT_MODEL = "gpt-5.4-mini"
EMBED_MODEL = "text-embedding-3-small"
COLLECTION_NAME = "meridian_documents"
PERSIST_DIR = "./chroma_store"
TOP_K = 3


# TODO A:
# Use hybrid retrieval because Meridian questions can contain both
# natural-language concepts and exact identifiers such as location
# codes (MFL-BLR-03) and role bands (Band B).


# TODO B:
# Cross-encoder reranking is not used for this pilot.
# Meridian's questions are generally narrow, and hybrid retrieval
# already combines BM25 keyword matching with semantic vector search.
# Additional reranking would add latency and complexity.


# TODO C:
# Additional document-level prompt-injection defence is not used for
# this pilot because the indexed HR documents are controlled and
# reviewed internal content.
# Grounding and refusal guardrails are still applied.


# TODO D:
# HybridIndex returns Reciprocal Rank Fusion (RRF) scores, which are
# much smaller than the toolkit's default confidence-score scale.
# These pilot thresholds are therefore expressed on the RRF scale.
# They should be validated against the supplied test questions.
HIGH_THRESHOLD = 0.030
MEDIUM_THRESHOLD = 0.020


SYSTEM_PROMPT = """
You are the Meridian Freight & Logistics HR Assistant.

Tone: Be concise, direct, practical, and easy to read on a mobile device.
Use simple language and avoid unnecessary technical or HR jargon.

Grounding rule: Only answer using the excerpts provided.

Every factual claim MUST be followed by a citation in the form
(Source: <filename>, Version: <version>).

If a source has no document version, do not invent one. Cite the source
using the metadata that is actually provided.

If the excerpts do not cover the question, say so plainly and do not guess.
"""


client = OpenAI()

embeddings = OpenAIEmbeddings(
    model=EMBED_MODEL
)

vectorstore = Chroma(
    collection_name=COLLECTION_NAME,
    embedding_function=embeddings,
    persist_directory=PERSIST_DIR,
)


# HybridIndex requires both the vector store and the stored documents.
stored = vectorstore.get(
    include=["documents", "metadatas"]
)

all_documents = [
    Document(
        page_content=text,
        metadata=metadata or {},
    )
    for text, metadata in zip(
        stored.get("documents", []),
        stored.get("metadatas", []),
    )
]

hybrid_index = HybridIndex(
    vectorstore,
    all_documents
)


app = FastAPI(
    title="Meridian Freight & Logistics HR Assistant"
)


@app.get("/")
def root():
    return {
        "message":
        "Meridian HR Assistant is running. Try /ask?q=your+question"
    }


@app.get("/ask")
def ask(q: str, top_k: int = TOP_K):
    tracer = Tracer()

    # ------------------------------------------------------------
    # TODO G:
    # Redact PII from the incoming question before retrieval/logging.
    # ------------------------------------------------------------

    with tracer.stage("pii_redact_input"):
        redacted_question, input_pii_redactions = redact_pii(q)


    # ------------------------------------------------------------
    # TODO H:
    # Hybrid BM25 + vector retrieval.
    # ------------------------------------------------------------

    with tracer.stage("retrieval"):
        raw_results = hybrid_index.hybrid_search(
            redacted_question,
            k=top_k,
        )


    # ------------------------------------------------------------
    # TODO D:
    # Calculate confidence using thresholds appropriate to the
    # hybrid retriever's RRF score scale.
    # ------------------------------------------------------------

    best_score = best_score_from_results(raw_results)

    level = confidence_level(
        best_score,
        high=HIGH_THRESHOLD,
        medium=MEDIUM_THRESHOLD,
    )


    # ------------------------------------------------------------
    # TODO I:
    # Refuse before calling the LLM when retrieval confidence
    # is insufficient.
    # ------------------------------------------------------------

    if should_refuse(
        best_score,
        medium=MEDIUM_THRESHOLD,
    ):
        refusal_answer = (
            "I don't have enough verified information in the available "
            "Meridian documents to answer that question."
        )

        retrieved_sources = [
            doc.metadata.get("source")
            for doc, score in raw_results
        ]

        retrieved_scores = [
            score
            for doc, score in raw_results
        ]

        audit_log.log_request(
            question_redacted=redacted_question,
            retrieved_sources=retrieved_sources,
            retrieved_scores=retrieved_scores,
            confidence_level=level,
            refused=True,
            injection_flagged=False,
            injection_details=None,
            output_validation_passed=None,
            output_validation_details=None,
            answer=refusal_answer,
            cited_sources=[],
            latency_sec=tracer.total_seconds(),
            prompt_tokens=0,
            completion_tokens=0,
            model=CHAT_MODEL,
        )

        return {
            "question": redacted_question,
            "confidence": level,
            "retrieved_chunks": [],
            "answer": refusal_answer,
            "sources": [],
            "trace": tracer.as_dict(),
        }


    # ------------------------------------------------------------
    # TODO J:
    # No additional reranking for the pilot.
    # ------------------------------------------------------------

    results = raw_results


    # ------------------------------------------------------------
    # TODO K:
    # Deduplicate and assemble retrieved context.
    # ------------------------------------------------------------

    context_text, used_results = assemble_context(results)


    # ------------------------------------------------------------
    # Version-aware context for TODO F.
    #
    # context.py includes source filenames but does not include the
    # version metadata. Add source/version headers here so the LLM
    # can actually produce version-aware citations.
    # ------------------------------------------------------------

    versioned_context_parts = []

    for doc, score in used_results:
        source = doc.metadata.get("source", "unknown")
        version = doc.metadata.get("version")

        if version:
            source_header = (
                f"(Source: {source}, Version: {version})"
            )
        else:
            source_header = (
                f"(Source: {source}, Version: not provided)"
            )

        versioned_context_parts.append(
            f"{source_header}\n{doc.page_content}"
        )

    versioned_context = "\n\n---\n\n".join(
        versioned_context_parts
    )


    # ------------------------------------------------------------
    # TODO L:
    # Build a grounded prompt and call the LLM.
    # ------------------------------------------------------------

    user_prompt = f"""
Retrieved HR document excerpts:

{versioned_context}

Employee question:
{redacted_question}

Answer using only the retrieved excerpts above.
Do not add information that is not supported by these excerpts.
"""

    with tracer.stage("llm"):
        response = client.chat.completions.create(
            model=CHAT_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT,
                },
                {
                    "role": "user",
                    "content": user_prompt,
                },
            ],
        )

    answer = response.choices[0].message.content


    # ------------------------------------------------------------
    # TODO M:
    # Audit logging.
    # ------------------------------------------------------------

    retrieved_sources = [
        doc.metadata.get("source")
        for doc, score in used_results
    ]

    retrieved_scores = [
        score
        for doc, score in used_results
    ]

    cited_sources = [
        {
            "source": doc.metadata.get("source"),
            "version": doc.metadata.get("version"),
        }
        for doc, score in used_results
    ]

    prompt_tokens = (
        response.usage.prompt_tokens
        if response.usage
        else 0
    )

    completion_tokens = (
        response.usage.completion_tokens
        if response.usage
        else 0
    )

    audit_log.log_request(
        question_redacted=redacted_question,
        retrieved_sources=retrieved_sources,
        retrieved_scores=retrieved_scores,
        confidence_level=level,
        refused=False,
        injection_flagged=False,
        injection_details=None,
        output_validation_passed=None,
        output_validation_details=None,
        answer=answer,
        cited_sources=cited_sources,
        latency_sec=tracer.total_seconds(),
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        model=CHAT_MODEL,
    )


    # ------------------------------------------------------------
    # TODO N:
    # Return the final API response.
    # ------------------------------------------------------------

    return {
        "question": redacted_question,
        "confidence": level,
        "retrieved_chunks": [
            {
                "text": doc.page_content,
                "source": doc.metadata.get("source"),
                "version": doc.metadata.get("version"),
                "score": score,
            }
            for doc, score in used_results
        ],
        "answer": answer,
        "sources": [
            {
                "source": doc.metadata.get("source"),
                "version": doc.metadata.get("version"),
            }
            for doc, score in used_results
        ],
        "trace": tracer.as_dict(),
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
    )